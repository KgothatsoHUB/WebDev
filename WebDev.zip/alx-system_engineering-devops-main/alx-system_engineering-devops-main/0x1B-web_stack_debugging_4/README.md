Web Stack Debugging #4
