# File Transfer Script

This script transfers a file from a client to a server using SCP.

## Usage

Run the script with the following parameters:

```bash
./0-transfer_file PATH_TO_FILE IP USERNAME PATH_TO_SSH_KEY

