Web Stack Debugging
