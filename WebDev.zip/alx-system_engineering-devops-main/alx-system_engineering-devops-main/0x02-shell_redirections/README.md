0x02. Shell, I/O Redirections and filter
