#!/usr/bin/env python3
from __import__('12-fizzbuzz').fizzbuzz

fizzbuzz()
print("\n")
