#!/usr/bin/env python3
from 9-print_last_digit import print_last_digit

print_last_digit(98)
print_last_digit(0)
r = print_last_digit(-1024)
print(f"The last digit is: {r}")

