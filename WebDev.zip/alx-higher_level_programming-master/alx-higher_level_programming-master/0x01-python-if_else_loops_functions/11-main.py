#!/usr/bin/env python3

# No need to import a custom pow function if using the built-in pow function

print(pow(2, 2))
print(pow(98, 2))
print(pow(98, 0))
print(pow(100, -2))
print(pow(-4, 5))

