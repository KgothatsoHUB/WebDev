#!/usr/bin/env python3
add = __import__('10-add').add

if __name__ == "__main__":
    print(add(1, 2))
    print(add(98, 0))
    print(add(100, -2))

