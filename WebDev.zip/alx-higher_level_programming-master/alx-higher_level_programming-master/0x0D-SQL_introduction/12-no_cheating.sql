-- Update the score of Bob to 10 in the table second_table in my MySQL server.
UPDATE `second_table`
SET `score` = 10
WHERE `name` = "Bob";

