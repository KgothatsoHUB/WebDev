0x0B. Python - Input/Output
