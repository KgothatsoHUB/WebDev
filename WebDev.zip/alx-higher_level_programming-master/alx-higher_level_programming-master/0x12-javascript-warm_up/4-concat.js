4-concat.js
#!/usr/bin/node
console.log(process.argv[2] + ' is ' + process.argv[3]);
