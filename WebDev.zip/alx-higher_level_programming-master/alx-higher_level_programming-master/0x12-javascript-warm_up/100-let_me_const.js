100-let_me_const.js
#!/usr/bin/node
myVar = 333;
