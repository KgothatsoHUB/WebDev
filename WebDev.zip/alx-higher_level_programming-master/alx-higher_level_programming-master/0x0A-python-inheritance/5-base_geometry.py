#!/usr/bin/python3
"""Defines an empty class BaseGeo."""


class BaseGeometry:
    """Represent base geo."""
    pass

