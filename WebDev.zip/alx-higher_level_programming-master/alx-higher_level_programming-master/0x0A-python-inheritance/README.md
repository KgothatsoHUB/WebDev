0x0a Pyhton - Inheritence
