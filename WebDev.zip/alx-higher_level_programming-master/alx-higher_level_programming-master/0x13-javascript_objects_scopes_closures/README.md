0x13. JavaScript - Objects, Scopes and Closures
