#!/usr/bin/node
class Rectangle {
}

module.exports = Rectangle;
