0x09. Python - Everything is object
