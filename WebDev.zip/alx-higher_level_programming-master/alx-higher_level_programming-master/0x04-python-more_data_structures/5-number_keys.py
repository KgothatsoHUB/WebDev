#!/usr/bin/python3
def number_keys(my_dict):
    return len(my_dict.keys())
