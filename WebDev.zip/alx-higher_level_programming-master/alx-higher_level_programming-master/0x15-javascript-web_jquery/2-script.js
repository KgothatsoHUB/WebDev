// Uses jQuery API to change color of div#red_header to red on click

$('div#red_header').click(function () {
    $('header').css('color', '#FF0000');
  });
