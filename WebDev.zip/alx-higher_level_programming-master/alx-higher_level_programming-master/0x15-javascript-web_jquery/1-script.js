// Use jQuery API to change color of header tag to red

$('header').css('color', '#FF0000');
