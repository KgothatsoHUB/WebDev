// Update text color of the HTML tag HEADER to red

document.querySelector('head').style.color = '#FF0000';
