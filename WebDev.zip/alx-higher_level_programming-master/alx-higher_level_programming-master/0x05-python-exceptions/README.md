Python Exceptions
