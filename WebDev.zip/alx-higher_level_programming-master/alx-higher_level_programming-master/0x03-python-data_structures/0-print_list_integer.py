#!/usr/bin/python3
def print_list_integer(_list=[]):
    for i in _list:
        print('{:d}'.format(i))
